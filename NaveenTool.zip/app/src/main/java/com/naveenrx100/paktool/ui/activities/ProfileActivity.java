package com.naveenrx100.paktool.ui.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.naveenrx100.paktool.NaveenApplication;
import com.naveenrx100.paktool.R;

/**
 * ProfileActivity — Profile / Settings screen.
 * CREDIT: @NaveenRx100
 */
public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView tvDev     = findViewById(R.id.tv_developer);
        TextView tvVersion = findViewById(R.id.tv_tool_version);
        Button   btnTg     = findViewById(R.id.btn_telegram);
        Button   btnAbout  = findViewById(R.id.btn_about);
        Button   btnHelp   = findViewById(R.id.btn_help);
        Button   btnShare  = findViewById(R.id.btn_share);
        Button   btnExit   = findViewById(R.id.btn_exit);
        Button   btnClean  = findViewById(R.id.btn_clean);

        tvDev.setText("Developer: " + NaveenApplication.DEVELOPER
                + "\nCredit: " + NaveenApplication.CREDIT);
        tvVersion.setText("v" + NaveenApplication.APP_VERSION);

        btnTg.setOnClickListener(v -> {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(NaveenApplication.TELEGRAM)));
        });

        btnAbout.setOnClickListener(v ->
            new AlertDialog.Builder(this)
                .setTitle("About  " + NaveenApplication.TOOL_NAME)
                .setMessage("Developer: " + NaveenApplication.DEVELOPER
                        + "\nCredit: " + NaveenApplication.CREDIT
                        + "\nTelegram: " + NaveenApplication.TELEGRAM
                        + "\n\nFeatures:\n• PAK unpack / repack\n• Lua decompile / recompile"
                        + "\n• SM4 / SIMPLE1 / SIMPLE2 / AES crypto\n• ZSTD + ZLIB compression"
                        + "\n• Block permutation (LCG)\n• Built-in file picker")
                .setPositiveButton("OK", null)
                .show());

        btnHelp.setOnClickListener(v ->
            new AlertDialog.Builder(this)
                .setTitle("Help")
                .setMessage("1. Copy PAK files to PAK TOOL/PAK/\n"
                        + "2. Use PAK Tools → Open PAK File\n"
                        + "3. Extract PAK to PAK TOOL/UNPACK/\n"
                        + "4. Copy .luac files to LUA_ORIGINAL/\n"
                        + "5. Use Lua Tools → DECOMPILE\n"
                        + "6. Edit .lua files in LUA_EDIT/\n"
                        + "7. Use Lua Tools → RECOMPILE\n"
                        + "8. Use Inject Tool → Inject PAK\n"
                        + "9. Output is in PAK_RESULT/")
                .setPositiveButton("OK", null)
                .show());

        btnShare.setOnClickListener(v -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT,
                    NaveenApplication.TOOL_NAME + "\nby " + NaveenApplication.CREDIT
                    + "\n" + NaveenApplication.TELEGRAM);
            startActivity(Intent.createChooser(share, "Share App"));
        });

        btnClean.setOnClickListener(v ->
            new AlertDialog.Builder(this)
                .setTitle("Clean All Working Directories?")
                .setMessage("This will delete LUA_EDIT, COMPILED, PAK_UNPACK, PAK_RESULT. Originals are kept.")
                .setPositiveButton("CLEAN", (d, w) -> cleanWorkDirs())
                .setNegativeButton("Cancel", null)
                .show());

        btnExit.setOnClickListener(v -> finishAffinity());
    }

    private void cleanWorkDirs() {
        int deleted = 0;
        for (java.io.File dir : new java.io.File[]{
                NaveenApplication.UNPACK_DIR,
                NaveenApplication.EDIT_DIR,
                NaveenApplication.PAK_UNPACK_DIR,
                NaveenApplication.RESULT_DIR,
                NaveenApplication.PAK_TOOL_UNPACK,
                NaveenApplication.PAK_TOOL_RESULT}) {
            if (dir.exists()) {
                java.io.File[] files = dir.listFiles();
                if (files != null) for (java.io.File f : files) {
                    f.delete(); deleted++;
                }
            }
        }
        Toast.makeText(this, "Cleaned " + deleted + " files.", Toast.LENGTH_SHORT).show();
    }
}
