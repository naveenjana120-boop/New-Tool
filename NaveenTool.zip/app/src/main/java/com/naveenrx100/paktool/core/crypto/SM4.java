package com.naveenrx100.paktool.core.crypto;

/**
 * SM4 Block Cipher — pure-Java port of the Python SM4 class in HXE.py
 *
 * CREDIT: @NaveenRx100
 *
 * SM4 is a 128-bit block cipher used in Chinese national standards (GB/T 32907-2016).
 * Tencent PAK files use SM4-ECB (no chaining) to encrypt individual 16-byte blocks.
 *
 * How it is used here:
 *  - Key is derived via SHA-1( fileStem.toLowerCase() + SM4_SECRET ) truncated to 16 bytes.
 *  - Each 16-byte block of content is encrypted / decrypted independently (ECB mode).
 *  - When the block_permutation (LCG) is active the physical block order is scrambled.
 */
public final class SM4 {

    public static final int KEY_LENGTH   = 16;
    public static final int BLOCK_LENGTH = 16;

    // ── S-Box (直接搬运Python bytes) ─────────────────────────────────────
    private static final int[] S_BOX = {
        52,102,37,116,137,120,228,169,90,65,188,122,214,22,33,35,
        77,97,218,148,155,223,19,60,105,58,49,10,95,215,153,149,
        241,174,114,61,7,96,36,182,152,238,196,162,45,136,221,141,
        4,234,187,17,202,62,93,161,246,63,176,151,128,71,43,166,
        230,247,217,177,89,192,124,190,84,40,183,126,79,248,67,110,
        160,80,14,245,144,184,251,163,123,98,25,70,3,42,185,143,
        159,119,180,91,131,135,8,235,226,30,66,240,15,232,113,106,
        117,173,85,31,181,171,51,250,127,21,189,133,216,6,104,179,
        82,48,72,11,0,237,239,178,87,142,231,108,213,229,46,83,
        130,5,249,129,244,86,191,140,75,227,219,74,145,76,44,211,
        64,41,78,32,20,54,121,9,111,209,55,224,57,12,138,146,
        56,18,53,109,225,253,147,154,23,212,201,156,107,132,38,157,
        175,118,193,158,208,150,197,203,233,115,73,210,205,100,195,199,
        1,125,243,172,252,222,164,68,50,27,194,186,28,2,198,39,
        69,139,242,24,167,16,81,29,200,207,99,255,47,13,88,206,
        101,165,220,26,59,134,254,34,92,168,94,103,170,236,112,204
    };

    // ── FK constants ──────────────────────────────────────────────────
    private static final long[] FK = {
        0xA3B1BAC6L, 0x56AA3350L, 0x677D9197L, 0xB27022DCL
    };

    // ── CK constants ──────────────────────────────────────────────────
    private static final long[] CK = {
        0x00070E15L,0x1C232A31L,0x383F464DL,0x545B6269L,
        0x70777E85L,0x8C939AA1L,0xA8AFB6BDL,0xC4CBD2D9L,
        0xE0E7EEF5L,0xFC030A11L,0x181F262DL,0x343B4249L,
        0x50575E65L,0x6C737A81L,0x888F969DL,0xA4ABB2B9L,
        0xC0C7CED5L,0xDCE3EAF1L,0xF8FF060DL,0x141B2229L,
        0x30373E45L,0x4C535A61L,0x686F767DL,0x848B9299L,
        0xA0A7AEB5L,0xBCC3CAD1L,0xD8DFE6EDL,0xF4FB0209L,
        0x10171E25L,0x2C333A41L,0x484F565DL,0x646B7279L
    };

    private final int[] rkey = new int[32];  // round keys

    // ── Constructor: expand key ───────────────────────────────────────
    public SM4(byte[] key) {
        if (key.length != KEY_LENGTH)
            throw new IllegalArgumentException("SM4 key must be exactly 16 bytes");
        keyExpand(key);
    }

    // ── Public API ────────────────────────────────────────────────────

    /** Encrypt a single 16-byte block (ECB, forward round keys). */
    public byte[] encrypt(byte[] block) {
        if (block.length != BLOCK_LENGTH)
            throw new IllegalArgumentException("Block must be 16 bytes");
        return crypt(block, false);
    }

    /** Decrypt a single 16-byte block (ECB, reverse round keys). */
    public byte[] decrypt(byte[] block) {
        if (block.length != BLOCK_LENGTH)
            throw new IllegalArgumentException("Block must be 16 bytes");
        return crypt(block, true);
    }

    /** ECB-encrypt an arbitrary-length byte array (must be 16-byte aligned). */
    public byte[] encryptECB(byte[] data) {
        if (data.length % BLOCK_LENGTH != 0)
            throw new IllegalArgumentException("Data length must be a multiple of 16");
        byte[] out = new byte[data.length];
        for (int i = 0; i < data.length; i += BLOCK_LENGTH) {
            byte[] block = new byte[BLOCK_LENGTH];
            System.arraycopy(data, i, block, 0, BLOCK_LENGTH);
            byte[] enc = encrypt(block);
            System.arraycopy(enc, 0, out, i, BLOCK_LENGTH);
        }
        return out;
    }

    /** ECB-decrypt an arbitrary-length byte array (must be 16-byte aligned). */
    public byte[] decryptECB(byte[] data) {
        if (data.length % BLOCK_LENGTH != 0)
            throw new IllegalArgumentException("Data length must be a multiple of 16");
        byte[] out = new byte[data.length];
        for (int i = 0; i < data.length; i += BLOCK_LENGTH) {
            byte[] block = new byte[BLOCK_LENGTH];
            System.arraycopy(data, i, block, 0, BLOCK_LENGTH);
            byte[] dec = decrypt(block);
            System.arraycopy(dec, 0, out, i, BLOCK_LENGTH);
        }
        return out;
    }

    // ── Private helpers ────────────────────────────────────────────────

    private byte[] crypt(byte[] block, boolean reverse) {
        int X0 = readInt32BE(block, 0);
        int X1 = readInt32BE(block, 4);
        int X2 = readInt32BE(block, 8);
        int X3 = readInt32BE(block, 12);

        for (int i = 0; i < 32; i += 4) {
            int r0 = reverse ? (31 - i) : i;
            int r1 = reverse ? (30 - i) : (i + 1);
            int r2 = reverse ? (29 - i) : (i + 2);
            int r3 = reverse ? (28 - i) : (i + 3);
            X0 = X0 ^ T0(X1 ^ X2 ^ X3 ^ rkey[r0]);
            X1 = X1 ^ T0(X2 ^ X3 ^ X0 ^ rkey[r1]);
            X2 = X2 ^ T0(X3 ^ X0 ^ X1 ^ rkey[r2]);
            X3 = X3 ^ T0(X0 ^ X1 ^ X2 ^ rkey[r3]);
        }

        byte[] out = new byte[BLOCK_LENGTH];
        writeInt32BE(out, 0,  X3);
        writeInt32BE(out, 4,  X2);
        writeInt32BE(out, 8,  X1);
        writeInt32BE(out, 12, X0);
        return out;
    }

    private void keyExpand(byte[] key) {
        long K0 = (readInt32BE(key, 0)  & 0xFFFFFFFFL) ^ FK[0];
        long K1 = (readInt32BE(key, 4)  & 0xFFFFFFFFL) ^ FK[1];
        long K2 = (readInt32BE(key, 8)  & 0xFFFFFFFFL) ^ FK[2];
        long K3 = (readInt32BE(key, 12) & 0xFFFFFFFFL) ^ FK[3];

        for (int i = 0; i < 32; i += 4) {
            K0 = (K0 ^ T1((K1 ^ K2 ^ K3 ^ CK[i])     & 0xFFFFFFFFL)) & 0xFFFFFFFFL;
            rkey[i]     = (int) K0;
            K1 = (K1 ^ T1((K2 ^ K3 ^ K0 ^ CK[i + 1]) & 0xFFFFFFFFL)) & 0xFFFFFFFFL;
            rkey[i + 1] = (int) K1;
            K2 = (K2 ^ T1((K3 ^ K0 ^ K1 ^ CK[i + 2]) & 0xFFFFFFFFL)) & 0xFFFFFFFFL;
            rkey[i + 2] = (int) K2;
            K3 = (K3 ^ T1((K0 ^ K1 ^ K2 ^ CK[i + 3]) & 0xFFFFFFFFL)) & 0xFFFFFFFFL;
            rkey[i + 3] = (int) K3;
        }
    }

    /** Non-linear transform τ (S-Box substitution on each byte). */
    private static int tau(int X) {
        return (S_BOX[(X >>> 24) & 0xFF] << 24) |
               (S_BOX[(X >>> 16) & 0xFF] << 16) |
               (S_BOX[(X >>>  8) & 0xFF] <<  8) |
               (S_BOX[ X         & 0xFF]);
    }

    /** Linear transform L (used in round function). */
    private static int T0(int X) {
        X = tau(X);
        return X ^ rol(X, 2) ^ rol(X, 10) ^ rol(X, 18) ^ rol(X, 24);
    }

    /** Linear transform L' (used in key expansion). */
    private static long T1(long Xl) {
        int X = (int) Xl;
        X = tau(X);
        return (long)(X ^ rol(X, 13) ^ rol(X, 23)) & 0xFFFFFFFFL;
    }

    private static int rol(int x, int n) {
        return (x << n) | (x >>> (32 - n));
    }

    // ── Byte-order helpers ─────────────────────────────────────────────

    private static int readInt32BE(byte[] b, int off) {
        return ((b[off]     & 0xFF) << 24) |
               ((b[off + 1] & 0xFF) << 16) |
               ((b[off + 2] & 0xFF) <<  8) |
               ( b[off + 3] & 0xFF);
    }

    private static void writeInt32BE(byte[] b, int off, int v) {
        b[off]     = (byte)((v >>> 24) & 0xFF);
        b[off + 1] = (byte)((v >>> 16) & 0xFF);
        b[off + 2] = (byte)((v >>>  8) & 0xFF);
        b[off + 3] = (byte)( v         & 0xFF);
    }
}
