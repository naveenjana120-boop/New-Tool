# NaveenRx100 PAK Tool — ProGuard rules
# CREDIT: @NaveenRx100

# Keep BouncyCastle (needed for SM4 / AES provider)
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**

# Keep zstd-jni
-keep class com.github.luben.zstd.** { *; }
-dontwarn com.github.luben.zstd.**

# Keep core PAK / Lua classes (no obfuscation — field names used in reflection)
-keep class com.naveenrx100.paktool.core.** { *; }
-keep class com.naveenrx100.paktool.NaveenApplication { *; }

# Keep activity names (used in Intent)
-keep public class com.naveenrx100.paktool.ui.activities.** { *; }
