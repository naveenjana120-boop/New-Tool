NaveenRx100 PAK Tool — Android source notes
================================================

What was changed
----------------
1. Removed the Windows PE executables lua53.dll and luac.exe (MZ headers).
2. Kept assets/luac5.3 after checking its header: it is a 64-bit little-endian
   ARM AArch64 Android executable (Android API 24 linker). LuaTools extracts it
   to the app cache, validates its ELF/ARM64 header, sets executable permission,
   and runs it with ProcessBuilder.
3. Renamed the ARM64 Android ELF previously named luadec.exe to luadec so it
   is not mistaken for a Windows executable.
4. Removed the `ProcessBuilder("java", "-jar", ...)` path. Decompilation now
   loads unluac.Main from assets/unluac_patched.dex with DexClassLoader and
   captures System.out as the generated Lua source.
5. Kept MANAGE_EXTERNAL_STORAGE and legacy/storage media permissions in the
   manifest. Replaced the missing @mipmap/ic_launcher reference with Android's
   built-in default app icon, which avoids a resource-linking failure.
6. Checked XML files for well-formedness.

Important runtime asset: unluac DEX
-----------------------------------
This ZIP intentionally does NOT pretend that the bundled JAR is already an
Android DEX file. LuaTools expects this file:

    app/src/main/assets/unluac_patched.dex

Convert the patched JAR with Android SDK build-tools (D8), for example:

    d8 --min-api 26 --output out app/src/main/assets/unluac_patched.jar

D8 output is normally named classes.dex. Copy that output to:
    app/src/main/assets/unluac_patched.dex

Use a D8 version compatible with your installed Android SDK. The DEX must
contain unluac/Main.class and its dependencies. If the patched JAR uses Java
APIs unsupported on Android, those APIs must be adapted before conversion.
Without this asset, Lua decompilation logs an error and saves the intermediate
bytecode fallback; Lua compilation via luac5.3 is independent.

Build notes
-----------
Open the NaveenTool folder in Android Studio and allow Gradle sync. The project
uses Android Gradle Plugin 8.3.2, compileSdk 34, Java 11, and CMake 3.22.1.
Android SDK/NDK and internet access for dependency resolution are required.
The source archive did not include a Gradle wrapper, so use Android Studio's
installed Gradle or add a wrapper from the IDE.

Storage
-------
MANAGE_EXTERNAL_STORAGE is a special app access on Android 11+. Declaring it
does not grant access automatically; users must enable "All files access" in
system settings. SAF document URIs should be preferred where possible. Some
Android versions/device vendors restrict direct access to shared storage.

Validation limitations
----------------------
This source archive was inspected and patched, but an Android Gradle build and
device-level tests could not be run in this environment. PAK parsing/crypto
correctness depends on matching the original Python implementation and should
be verified against known-good PAK fixtures before production use. No claim is
made that every PAK variant or every UI workflow is error-free.


GRADLE 7.4.2 COMPATIBILITY / DOWNLOAD TIMEOUT
- Root build.gradle uses Android Gradle Plugin 7.3.1, compatible with Gradle 7.4.2.
- gradle.properties increases Maven/Gradle HTTP connection and socket timeouts and configures retries.
- The reported netty-codec-http2 and org.json errors are Maven Central download timeouts, not Java source compilation errors. A working/stable internet connection is still required; Gradle cannot build dependencies that it cannot download.
- In your build app, retry the build after switching to stable Wi-Fi/mobile data. If the same artifact repeatedly times out, clear only the Gradle download cache if your build app supports it, then retry.
