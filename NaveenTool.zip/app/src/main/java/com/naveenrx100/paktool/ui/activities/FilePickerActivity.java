package com.naveenrx100.paktool.ui.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.naveenrx100.paktool.R;
import com.naveenrx100.paktool.utils.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * FilePickerActivity — built-in file browser.
 *
 * CREDIT: @NaveenRx100
 *
 * Behaves like a simplified MT Manager:
 *  • Browse /storage/emulated/0/ directory tree
 *  • Tap a file to select it and return to caller
 *  • Long-press a folder to return the folder path
 *  • Optionally filter by extension (passed via Intent extra EXTRA_FILTER)
 *
 * Usage:
 *   Intent i = new Intent(ctx, FilePickerActivity.class);
 *   i.putExtra(FilePickerActivity.EXTRA_FILTER, ".pak");   // optional
 *   i.putExtra(FilePickerActivity.EXTRA_MODE, MODE_FILE);  // or MODE_FOLDER
 *   startActivityForResult(i, REQUEST_CODE);
 *
 * Result:
 *   data.getStringExtra(FilePickerActivity.RESULT_PATH)
 */
public class FilePickerActivity extends AppCompatActivity {

    public static final String EXTRA_FILTER      = "filter";
    public static final String EXTRA_MODE        = "mode";
    public static final String RESULT_PATH       = "selected_path";
    public static final int    MODE_FILE         = 0;
    public static final int    MODE_FOLDER       = 1;

    private RecyclerView recyclerView;
    private TextView     tvCurrentPath, tvEmpty;
    private Button       btnBack, btnSelectFolder;

    private File         currentDir;
    private String       filterExt;
    private int          mode = MODE_FILE;
    private FileAdapter  adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_picker);

        recyclerView   = findViewById(R.id.rv_files);
        tvCurrentPath  = findViewById(R.id.tv_current_path);
        tvEmpty        = findViewById(R.id.tv_empty);
        btnBack        = findViewById(R.id.btn_back_dir);
        btnSelectFolder= findViewById(R.id.btn_select_folder);

        filterExt = getIntent().getStringExtra(EXTRA_FILTER);
        mode      = getIntent().getIntExtra(EXTRA_MODE, MODE_FILE);

        btnSelectFolder.setVisibility(mode == MODE_FOLDER ? View.VISIBLE : View.GONE);
        btnSelectFolder.setOnClickListener(v -> returnPath(currentDir.getAbsolutePath()));
        btnBack.setOnClickListener(v -> navigateUp());

        currentDir = Environment.getExternalStorageDirectory();
        navigate(currentDir);
    }

    @Override
    public void onBackPressed() {
        if (!navigateUp()) super.onBackPressed();
    }

    private boolean navigateUp() {
        File parent = currentDir.getParentFile();
        if (parent != null && parent.canRead()) {
            navigate(parent);
            return true;
        }
        return false;
    }

    private void navigate(File dir) {
        currentDir = dir;
        tvCurrentPath.setText(dir.getAbsolutePath());

        List<File> items = new ArrayList<>();
        File[] children = dir.listFiles();
        if (children != null) {
            Arrays.sort(children, (a, b) -> {
                if (a.isDirectory() && !b.isDirectory()) return -1;
                if (!a.isDirectory() && b.isDirectory()) return 1;
                return a.getName().compareToIgnoreCase(b.getName());
            });
            for (File f : children) {
                if (f.isDirectory()) {
                    items.add(f);
                } else if (filterExt == null || f.getName().endsWith(filterExt)) {
                    items.add(f);
                }
            }
        }

        tvEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);

        adapter = new FileAdapter(items, file -> {
            if (file.isDirectory()) {
                navigate(file);
            } else {
                returnPath(file.getAbsolutePath());
            }
        }, file -> {
            // Long-press: return folder
            if (file.isDirectory()) returnPath(file.getAbsolutePath());
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void returnPath(String path) {
        Intent result = new Intent();
        result.putExtra(RESULT_PATH, path);
        setResult(Activity.RESULT_OK, result);
        finish();
    }

    // ── RecyclerView Adapter ─────────────────────────────────────────

    interface OnFileClick { void onClick(File f); }

    static class FileAdapter extends RecyclerView.Adapter<FileAdapter.VH> {
        private final List<File>  items;
        private final OnFileClick onClick, onLongClick;

        FileAdapter(List<File> items, OnFileClick onClick, OnFileClick onLongClick) {
            this.items       = items;
            this.onClick     = onClick;
            this.onLongClick = onLongClick;
        }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_file, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            File f = items.get(pos);
            h.name.setText(f.getName());
            h.info.setText(f.isDirectory()
                    ? "📁 Folder"
                    : "📄 " + FileUtils.humanSize(f.length()));
            h.itemView.setOnClickListener(v -> onClick.onClick(f));
            h.itemView.setOnLongClickListener(v -> { onLongClick.onClick(f); return true; });
        }

        @Override public int getItemCount() { return items.size(); }

        static class VH extends RecyclerView.ViewHolder {
            TextView name, info;
            VH(View v) {
                super(v);
                name = v.findViewById(R.id.tv_file_name);
                info = v.findViewById(R.id.tv_file_info);
            }
        }
    }
}
