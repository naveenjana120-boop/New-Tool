package com.naveenrx100.paktool.core.lua;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/**
 * LuaConverter — direct port of the Python Lua XOR + opcode remapping logic.
 *
 * CREDIT: @NaveenRx100
 *
 * What BGMI/Tencent does to Lua bytecode:
 *  1. Strings are XOR-encoded with a 32-byte key (STRING_XOR_KEY).
 *  2. Opcodes are remapped via a custom permutation table (BGMI_TO_STD).
 *  3. Absolute line numbers are stored as delta bytes (single byte, -128..127).
 *  4. (optional) nibble-swap of all bytes past the header.
 *
 * bgmiToStd()  — converts BGMI .luac → standard Lua 5.3 .luac (for unluac)
 * stdToBgmi()  — converts compiled standard .luac → BGMI .luac (for injection)
 */
public final class LuaConverter {

    // ── XOR key (Python: STRING_XOR_KEY) ─────────────────────────────
    private static final byte[] STRING_XOR_KEY = {
        0x11,0x21,0x36,0x47,0x46,0x57,(byte)0xA7,(byte)0x8D,
        (byte)0x9D,(byte)0x84,(byte)0x90,(byte)0xD8,(byte)0xAB,0x00,(byte)0x8C,0x35,
        0x26,0x1A,(byte)0xF7,(byte)0xE4,0x58,0x05,(byte)0xB8,(byte)0xB3,
        0x15,0x07,(byte)0xD0,0x2C,0x1E,(byte)0x8F,(byte)0xF6,(byte)0xC8
    };

    // ── Opcode remapping (Python: _BGMI_TO_STD + padding) ─────────────
    private static final int[] BGMI_TO_STD = {
        13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,30,31,32,33,
        34,35,36,37,38,39,40,41,42,43,44,45,46,
        47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63
    };

    // Inverse: STD_TO_BGMI[stdOp] = bgmiOp
    private static final int[] STD_TO_BGMI = new int[64];

    static {
        for (int i = 0; i < 64; i++) STD_TO_BGMI[i] = i;
        // Build inverse for opcode range 0..46
        for (int bgmi = 0; bgmi < 47; bgmi++) {
            STD_TO_BGMI[BGMI_TO_STD[bgmi]] = bgmi;
        }
    }

    // ── Instruction format codes ───────────────────────────────────────
    // iABC=0, iABx=1, iAsBx=2, iAx=3
    private static final int[] STD_FMT = {
        0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,
        0,0,0,0,0,0,0,2,2,0,2,0,1,0,3
    };
    private static final int I_ABC  = 0;
    private static final int I_ABX  = 1;
    private static final int I_ASBX = 2;
    private static final int I_AX   = 3;

    private static final int HEADER_SIZE = 33;

    // ════════════════════════════════════════════════════════════════════
    // Public API
    // ════════════════════════════════════════════════════════════════════

    /**
     * Converts BGMI Lua bytecode to standard Lua 5.3 bytecode.
     * Input must start with the Lua magic bytes 0x1bLua.
     *
     * @return standard bytecode ready for unluac
     * @throws LuaConvertException on parse error
     */
    public static byte[] bgmiToStd(byte[] data) throws LuaConvertException {
        validateHeader(data);

        // Handle nibble-swap encoding (nibble_flag > 1)
        int nibbleFlag = data.length > 33 ? (data[33] & 0xFF) : 0;
        if (nibbleFlag > 2) nibbleFlag = 0;
        if (nibbleFlag > 1) {
            byte[] fixed = Arrays.copyOf(data, 34);
            for (int i = 34; i < data.length; i++) {
                byte b = data[i];
                fixed = appendByte(fixed, (byte)(((b << 4) & 0xF0) | ((b >>> 4) & 0x0F)));
            }
            data = fixed;
        }

        Reader reader = new Reader(data, 4);
        Writer writer = new Writer();

        // Copy header, but force sizet = 4 at byte offset 13
        byte[] hdr = Arrays.copyOf(data, HEADER_SIZE);
        hdr[13] = 4;
        writer.raw(hdr);
        reader.pos = HEADER_SIZE;

        int nf = reader.byte_(); writer.byte_(nf);
        convertFunction(reader, writer, true);
        return writer.get();
    }

    /**
     * Converts standard Lua 5.3 bytecode (output of luac5.3) to BGMI encoding.
     * Mirrors the original BGMI header from {@code originalBgmi}.
     *
     * @param stdData       compiled standard bytecode
     * @param originalBgmi  the original BGMI .luac for header / nibble flag reference
     * @return BGMI-encoded bytecode ready for PAK injection
     * @throws LuaConvertException on parse error
     */
    public static byte[] stdToBgmi(byte[] stdData, byte[] originalBgmi) throws LuaConvertException {
        validateHeader(stdData);
        if (originalBgmi == null || originalBgmi.length < 34) {
            // No original → produce with nibble_flag = 0
            return stdToBgmiNoOriginal(stdData);
        }

        int nibbleFlag = originalBgmi[33] & 0xFF;
        if (nibbleFlag > 2) nibbleFlag = 0;

        byte[] header = Arrays.copyOf(originalBgmi, HEADER_SIZE);
        header[13] = 4; // force sizet = 4

        int sizet = (stdData[13] & 0xFF);
        if (sizet != 4 && sizet != 8) sizet = 4;
        Reader reader = new Reader(stdData, sizet);
        Writer writer = new Writer();

        writer.raw(header);
        reader.pos = HEADER_SIZE;

        int nf = reader.byte_(); writer.byte_(nf);
        convertFunction(reader, writer, false);

        byte[] result = writer.get();

        // Re-apply nibble swap if original used it
        if (nibbleFlag > 1) {
            byte[] swapped = Arrays.copyOf(result, 34);
            for (int i = 34; i < result.length; i++) {
                byte b = result[i];
                swapped = appendByte(swapped, (byte)(((b << 4) & 0xF0) | ((b >>> 4) & 0x0F)));
            }
            result = swapped;
        }

        return result;
    }

    private static byte[] stdToBgmiNoOriginal(byte[] stdData) throws LuaConvertException {
        int sizet = stdData[13] & 0xFF;
        if (sizet != 4 && sizet != 8) sizet = 4;
        Reader reader = new Reader(stdData, sizet);
        Writer writer = new Writer();
        byte[] hdr = Arrays.copyOf(stdData, HEADER_SIZE);
        hdr[13] = 4;
        writer.raw(hdr);
        reader.pos = HEADER_SIZE;
        int nf = reader.byte_(); writer.byte_(nf);
        convertFunction(reader, writer, false);
        return writer.get();
    }

    // ════════════════════════════════════════════════════════════════════
    // Core recursive conversion
    // ════════════════════════════════════════════════════════════════════

    private static void convertFunction(Reader r, Writer w, boolean toStd)
            throws LuaConvertException {
        // source name
        String src = toStd ? r.pubgString() : r.stdString();
        w.luaString(src, !toStd);

        // line defined, last line defined
        int lineDefined = r.int32(); w.int32(lineDefined);
        w.int32(r.int32());

        // numparams, is_vararg, maxstacksize
        w.byte_(r.byte_()); w.byte_(r.byte_()); w.byte_(r.byte_());

        // instructions
        int csz = r.uint32(); w.uint32(csz);
        int[] opmap = toStd ? BGMI_TO_STD : STD_TO_BGMI;
        for (int i = 0; i < csz; i++) {
            long raw = r.uint32() & 0xFFFFFFFFL;
            int bop  = (int)(raw         & 0x3F);
            int A    = (int)((raw >>>  6) & 0xFF);
            int B    = (int)((raw >>> 23) & 0x1FF);
            int C    = (int)((raw >>> 14) & 0x1FF);
            int Bx   = (int)((raw >>> 14) & 0x3FFFF);
            int sBx  = Bx - 131071;
            int Ax   = (int)((raw >>>  6) & 0x3FFFFFF);

            int sop  = (bop < opmap.length) ? opmap[bop] : bop;
            int fmt  = (sop < STD_FMT.length) ? STD_FMT[sop] : I_ABC;
            w.luaInst(sop, A, B, C, Bx, sBx, Ax, fmt);
        }

        // constants
        int nk = r.uint32(); w.uint32(nk);
        for (int i = 0; i < nk; i++) {
            int t = r.byte_(); w.byte_(t);
            switch (t) {
                case 0: break; // LUA_TNIL
                case 1: w.byte_(r.byte_()); break; // LUA_TBOOLEAN
                case 3: w.double_(r.double_()); break; // LUA_TNUMBER (float)
                case 19: w.int64(r.int64()); break;   // LUA_TNUMINT
                case 4: case 20: // LUA_TSTRING
                    String s = toStd ? r.pubgString() : r.stdString();
                    w.luaString(s, !toStd);
                    break;
                default:
                    throw new LuaConvertException("Unknown constant type: 0x" + Integer.toHexString(t));
            }
        }

        // upvalues
        int nups = r.uint32(); w.uint32(nups);
        for (int i = 0; i < nups; i++) { w.byte_(r.byte_()); w.byte_(r.byte_()); }

        // nested functions
        int npts = r.uint32(); w.uint32(npts);
        for (int i = 0; i < npts; i++) convertFunction(r, w, toStd);

        // line info
        int nln = r.uint32();
        if (toStd) {
            // BGMI: delta-encoded bytes → standard: absolute int32
            int[] lines = new int[nln];
            int cur = lineDefined;
            for (int i = 0; i < nln; i++) {
                int d = r.byte_();
                if (d > 127) d -= 256; // signed byte
                cur += d;
                lines[i] = cur;
            }
            w.uint32(lines.length);
            for (int ln : lines) w.int32(ln);
            // Skip abslineinfo (BGMI v5 extra)
            int nab = r.uint32();
            for (int i = 0; i < nab; i++) { r.uint32(); r.uint32(); }
        } else {
            // Standard: absolute int32 → BGMI: delta bytes
            int[] lines = new int[nln];
            for (int i = 0; i < nln; i++) lines[i] = r.int32();
            w.uint32(lines.length);
            int prev = lineDefined;
            for (int ln : lines) {
                int delta = ln - prev;
                if (delta >= -128 && delta <= 127) {
                    w.byte_(delta & 0xFF);
                } else {
                    w.byte_(0);
                    w.int32(delta);
                }
                prev = ln;
            }
            w.uint32(0); // no abslineinfo
        }

        // locals
        int nloc = r.uint32(); w.uint32(nloc);
        for (int i = 0; i < nloc; i++) {
            String ls = toStd ? r.pubgString() : r.stdString();
            w.luaString(ls, !toStd);
            w.int32(r.int32()); w.int32(r.int32());
        }

        // upvalue names
        int nupn = r.uint32(); w.uint32(nupn);
        for (int i = 0; i < nupn; i++) {
            String us = toStd ? r.pubgString() : r.stdString();
            w.luaString(us, !toStd);
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // Validation
    // ════════════════════════════════════════════════════════════════════

    private static void validateHeader(byte[] data) throws LuaConvertException {
        if (data == null || data.length < 4 ||
            data[0] != 0x1b || data[1] != 'L' || data[2] != 'u' || data[3] != 'a') {
            throw new LuaConvertException("Not a valid Lua bytecode file (missing 0x1bLua magic)");
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // Inner Reader
    // ════════════════════════════════════════════════════════════════════

    private static final class Reader {
        final byte[] data;
        int pos;
        final int sizet;

        Reader(byte[] data, int sizet) { this.data = data; this.pos = 0; this.sizet = sizet; }

        int byte_() { return data[pos++] & 0xFF; }

        int int32() {
            int v = ByteBuffer.wrap(data, pos, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
            pos += 4; return v;
        }

        int uint32() { return int32(); }

        long int64() {
            long v = ByteBuffer.wrap(data, pos, 8).order(ByteOrder.LITTLE_ENDIAN).getLong();
            pos += 8; return v;
        }

        double double_() {
            double v = ByteBuffer.wrap(data, pos, 8).order(ByteOrder.LITTLE_ENDIAN).getDouble();
            pos += 8; return v;
        }

        byte[] bytes(int n) {
            byte[] b = Arrays.copyOfRange(data, pos, pos + n); pos += n; return b;
        }

        /** BGMI-encoded string: XOR-encoded with STRING_XOR_KEY */
        String pubgString() {
            int sz = byte_();
            if (sz == 0xFF) {
                if (sizet == 8) { sz = (int)(ByteBuffer.wrap(data, pos, 8)
                        .order(ByteOrder.LITTLE_ENDIAN).getLong()); pos += 8; }
                else { sz = uint32(); }
            }
            if (sz == 0) return null;
            sz--;
            byte[] enc = bytes(sz);
            byte[] dec = new byte[enc.length];
            for (int i = 0; i < enc.length; i++)
                dec[i] = (byte)(enc[i] ^ STRING_XOR_KEY[i % 32]);
            try { return new String(dec, "UTF-8"); } catch (Exception e) { return new String(dec); }
        }

        /** Standard Lua 5.3 string: no XOR */
        String stdString() {
            int sz = byte_();
            if (sz == 0xFF) {
                if (sizet == 8) { sz = (int)(ByteBuffer.wrap(data, pos, 8)
                        .order(ByteOrder.LITTLE_ENDIAN).getLong()); pos += 8; }
                else { sz = uint32(); }
            }
            if (sz == 0) return null;
            sz--;
            byte[] raw = bytes(sz);
            try { return new String(raw, "UTF-8"); } catch (Exception e) { return new String(raw); }
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // Inner Writer
    // ════════════════════════════════════════════════════════════════════

    private static final class Writer {
        private final ByteArrayOutputStream buf = new ByteArrayOutputStream();

        void byte_(int v)   { buf.write(v & 0xFF); }
        void raw(byte[] d)  { try { buf.write(d); } catch (Exception ignored) {} }

        void int32(int v) {
            buf.write( v        & 0xFF);
            buf.write((v >>  8) & 0xFF);
            buf.write((v >> 16) & 0xFF);
            buf.write((v >> 24) & 0xFF);
        }

        void uint32(int v) { int32(v); }

        void int64(long v) {
            int32((int)(v & 0xFFFFFFFFL));
            int32((int)(v >>> 32));
        }

        void double_(double v) {
            long bits = Double.doubleToLongBits(v);
            int32((int)(bits & 0xFFFFFFFFL));
            int32((int)(bits >>> 32));
        }

        void luaString(String s, boolean pubg) {
            if (s == null) { byte_(0); return; }
            byte[] e;
            try { e = s.getBytes("UTF-8"); } catch (Exception ex) { e = s.getBytes(); }
            int sz = e.length + 1;
            if (sz < 0xFF) byte_(sz);
            else { byte_(0xFF); uint32(sz); }
            if (pubg) {
                byte[] enc = new byte[e.length];
                for (int i = 0; i < e.length; i++) enc[i] = (byte)(e[i] ^ STRING_XOR_KEY[i % 32]);
                raw(enc);
            } else {
                raw(e);
            }
        }

        /** Encode a Lua 5.3 instruction into 32-bit LE word. */
        void luaInst(int op, int A, int B, int C, int Bx, int sBx, int Ax, int fmt) {
            op &= 0x3F;
            int r;
            switch (fmt) {
                case I_ABC:  r = op | ((A & 0xFF) << 6) | ((C & 0x1FF) << 14) | ((B & 0x1FF) << 23); break;
                case I_ABX:  r = op | ((A & 0xFF) << 6) | ((Bx & 0x3FFFF) << 14); break;
                case I_ASBX: r = op | ((A & 0xFF) << 6) | (((sBx + 131071) & 0x3FFFF) << 14); break;
                case I_AX:   r = op | ((Ax & 0x3FFFFFF) << 6); break;
                default:     r = 0;
            }
            int32(r);
        }

        byte[] get() { return buf.toByteArray(); }
    }

    // ════════════════════════════════════════════════════════════════════
    // Misc
    // ════════════════════════════════════════════════════════════════════

    private static byte[] appendByte(byte[] arr, byte b) {
        byte[] out = Arrays.copyOf(arr, arr.length + 1);
        out[arr.length] = b;
        return out;
    }

    // ── Exception ─────────────────────────────────────────────────────
    public static class LuaConvertException extends Exception {
        public LuaConvertException(String msg) { super(msg); }
    }
}
