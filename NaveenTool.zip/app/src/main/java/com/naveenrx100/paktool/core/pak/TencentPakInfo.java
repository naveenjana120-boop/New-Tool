package com.naveenrx100.paktool.core.pak;

import com.naveenrx100.paktool.core.crypto.PakCrypto;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/**
 * TencentPakInfo — parses the variable-length PAK footer.
 *
 * CREDIT: @NaveenRx100
 *
 * Mirrors Python classes PakInfo + TencentPakInfo.
 *
 * Footer layout (grows backwards from end of file, version dependent):
 *
 *  [v≥12] content_org_hash   20 bytes
 *  [v≥9 ] stem_hash          4  bytes  (XOR ks[8])
 *  [v≥9 ] unk2               4  bytes  (XOR ks[9])
 *  [v≥8 ] packed_key         256 bytes
 *  [v≥8 ] packed_iv          256 bytes
 *  [v≥8 ] packed_index_hash  256 bytes
 *  [v≥7 ] unk1               32  bytes (XOR ks[7..14])
 *  [v≥6 ] index_hash         20  bytes (XOR ks[4..8])  ← base PakInfo
 *  [   ] index_encrypted     1   byte  (XOR ks[3])
 *  [   ] magic               4   bytes (XOR ks[2])
 *  [   ] version             4   bytes (plain)
 *  [   ] index_hash_base     20  bytes (XOR ks[4..8])
 *  [   ] index_size          8   bytes (XOR (ks[10]<<32|ks[11]))
 *  [   ] index_offset        8   bytes (XOR (ks[0]<<32|ks[1]))
 *
 * The base PakInfo consumes 45 bytes at the very end.
 * TencentPakInfo adds extra fields before that 45-byte block.
 */
public class TencentPakInfo {

    // ── Decoded fields (public for easy read access) ──────────────────
    public final boolean indexEncrypted;
    public final long    magic;
    public final int     version;
    public final byte[]  indexHash;         // 20 bytes  (v≥6)
    public final long    indexSize;         // uint64
    public final long    indexOffset;       // uint64

    // Tencent-specific extensions
    public final byte[]  unk1;              // 32 bytes  (v≥7)
    public final byte[]  packedKey;         // 256 bytes (v≥8)
    public final byte[]  packedIv;          // 256 bytes (v≥8)
    public final byte[]  packedIndexHash;   // 256 bytes (v≥8)
    public final long    stemHash;          // uint32    (v≥9)
    public final long    unk2;              // uint32    (v≥9)
    public final byte[]  contentOrgHash;    // 20 bytes  (v≥12)

    // Total size of the footer in bytes (varies by version)
    public final int footerSize;

    // ── Base PakInfo size constant ────────────────────────────────────
    // Python: PakInfo._mem_size(-1) == 45
    private static final int BASE_SIZE = 45;

    /**
     * Parse the footer from raw file bytes.
     *
     * @param fileBytes  full file contents
     * @param keystream  16-element ZUC keystream array
     */
    public TencentPakInfo(byte[] fileBytes, long[] keystream) {
        // ── Step 1: peek at base block to get version ─────────────────
        // Base block is always the last 45 bytes.
        if (fileBytes.length < BASE_SIZE)
            throw new IllegalArgumentException("File too small to contain PAK footer");

        ByteBuffer base = ByteBuffer.wrap(fileBytes,
                fileBytes.length - BASE_SIZE, BASE_SIZE)
                .order(ByteOrder.LITTLE_ENDIAN);

        int rawFlag   = base.get()  & 0xFF;
        long rawMagic = base.getInt() & 0xFFFFFFFFL;
        int  ver      = base.getInt();

        this.indexEncrypted = PakCrypto.decryptIndexEncryptedFlag(rawFlag, keystream);
        this.magic          = PakCrypto.decryptMagic(rawMagic, keystream);
        this.version        = ver;

        // index_hash 20 bytes (only meaningful for v≥6)
        byte[] rawHash = new byte[20];
        base.get(rawHash);
        this.indexHash = (ver >= 6)
                ? PakCrypto.decryptIndexHash(rawHash, keystream)
                : new byte[20];

        long rawIndexSize   = base.getLong();
        long rawIndexOffset = base.getLong();
        this.indexSize   = PakCrypto.decryptIndexSize(rawIndexSize, keystream);
        this.indexOffset = PakCrypto.decryptIndexOffset(rawIndexOffset, keystream);

        // Version ≤ 3 → not encrypted regardless
        boolean encFlag = (ver <= 3) ? false : this.indexEncrypted;

        // ── Step 2: parse version-specific extension fields ───────────
        int extraSize = 0;
        if (ver >= 12) extraSize += 20;   // content_org_hash
        if (ver >= 9)  extraSize += 8;    // stem_hash + unk2
        if (ver >= 8)  extraSize += 768;  // 3 × 256
        if (ver >= 7)  extraSize += 32;   // unk1

        this.footerSize = BASE_SIZE + extraSize;

        if (fileBytes.length < footerSize)
            throw new IllegalArgumentException(
                    "File too small for PAK footer (need " + footerSize + " bytes)");

        // Extension block sits immediately before the base 45 bytes
        ByteBuffer ext = ByteBuffer.wrap(fileBytes,
                fileBytes.length - footerSize, extraSize)
                .order(ByteOrder.LITTLE_ENDIAN);

        // Read in the SAME order they were written (low offset first)
        if (ver >= 7) {
            byte[] rawUnk1 = new byte[32];
            ext.get(rawUnk1);
            // Decrypt: XOR with ks[7..14] packed as 8 uint32 LE
            byte[] ksBytes = new byte[32];
            ByteBuffer ksb = ByteBuffer.wrap(ksBytes).order(ByteOrder.LITTLE_ENDIAN);
            for (int i = 7; i < 15; i++) ksb.putInt((int)(keystream[i] & 0xFFFFFFFFL));
            byte[] decUnk1 = new byte[32];
            for (int i = 0; i < 32; i++) decUnk1[i] = (byte)(rawUnk1[i] ^ ksBytes[i]);
            this.unk1 = decUnk1;
        } else {
            this.unk1 = new byte[0];
        }

        if (ver >= 8) {
            this.packedKey        = new byte[256]; ext.get(this.packedKey);
            this.packedIv         = new byte[256]; ext.get(this.packedIv);
            this.packedIndexHash  = new byte[256]; ext.get(this.packedIndexHash);
        } else {
            this.packedKey       = new byte[0];
            this.packedIv        = new byte[0];
            this.packedIndexHash = new byte[0];
        }

        if (ver >= 9) {
            long rawStemHash = ext.getInt() & 0xFFFFFFFFL;
            long rawUnk2     = ext.getInt() & 0xFFFFFFFFL;
            this.stemHash = rawStemHash ^ (keystream[8] & 0xFFFFFFFFL);
            this.unk2     = rawUnk2     ^ (keystream[9] & 0xFFFFFFFFL);
        } else {
            this.stemHash = 0;
            this.unk2     = 0;
        }

        if (ver >= 12) {
            this.contentOrgHash = new byte[20]; ext.get(this.contentOrgHash);
        } else {
            this.contentOrgHash = new byte[0];
        }
    }

    /**
     * Returns the total footer size for a given version.
     * Used when building new footers.
     */
    public static int footerSizeForVersion(int version) {
        int extra = 0;
        if (version >= 12) extra += 20;
        if (version >= 9)  extra += 8;
        if (version >= 8)  extra += 768;
        if (version >= 7)  extra += 32;
        return BASE_SIZE + extra;
    }
}
